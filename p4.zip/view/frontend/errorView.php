<?php $title = "Inscrivez-vous"; ?>

<?php ob_start(); ?>





<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>